find("click.png")
click("click-1.png")
